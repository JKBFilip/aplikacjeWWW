-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sty 16, 2025 at 03:26 PM
-- Wersja serwera: 10.4.32-MariaDB
-- Wersja PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `moja_strona`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `page_list`
--

CREATE TABLE `page_list` (
  `ID` int(11) NOT NULL,
  `page_title` varchar(255) NOT NULL,
  `page_content` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `page_list`
--

INSERT INTO `page_list` (`ID`, `page_title`, `page_content`, `status`) VALUES
(1, 'akwarium', '\r\n<h1 class=\"header\">Akwarium</h1>\r\n<h2>Zarówno dla zdrowia, jak i komfortu żółwia, niezbędne jest zapewnienie odpowiedniej wielkości akwarium. Powinno ono mieć wystarczającą przestrzeń do pływania oraz strefę lądową, gdzie żółw może się wygrzewać. Zainwestuj w dobry filtr, który utrzyma wodę w czystości, oraz grzałkę, aby utrzymać odpowiednią temperaturę. Pamiętaj, że akwarium powinno być regularnie czyszczone, aby zapobiec rozwojowi szkodliwych bakterii. </h2>\r\n	\r\n<td><img src=\"obrazy/akwarium.jpg\" width=95% height=70% alt=\"akwarium\"></td>\r\n', 1),
(2, 'filmy', '\r\n	\r\n<header>\r\n        <h1>Filmy o Żółwiach Wodnych</h1>\r\n        <p>Poniżej znajdziesz wybrane filmy przedstawiające fascynujący świat żółwi wodnych.</p>\r\n    </header>\r\n\r\n    <section class=\"video-gallery\">\r\n        <!-- Pierwszy film -->\r\n        <div class=\"video\">\r\n            <h2>Ciekawostki o hodowli żółwia wodnego</h2>\r\n            <iframe width=\"560\" height=\"315\" src=\"https://youtu.be/r43RmAE9U18?si=EG_KIEWrTPnYFMSD\"></iframe>\r\n            <p>Zbiór informacji o hodowli żółwi wodnych</p>\r\n        </div>\r\n\r\n        <!-- Drugi film -->\r\n        <div class=\"video\">\r\n            <h2>15 najlepszych gatunków żółwi wodnych</h2>\r\n            <iframe width=\"560\" height=\"315\" src=\"https://youtu.be/6f0e1g0bxcs?si=xNSheJLPFK_lBN12\" title=\"Podróż młodego żółwia\"\r\n                    frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>\r\n            <p>Lista najlepszych do hodowli gatunków żółwi </p>\r\n        </div>\r\n\r\n        <!-- Trzeci film -->\r\n        <div class=\"video\">\r\n            <h2>Żółw morski na Sri Lance</h2>\r\n            <iframe width=\"560\" height=\"315\" src=\"https://youtu.be/0IugWffMaGU?si=cQNs15JbXehoA9FE\" title=\"Żółwie wodne w ich naturalnym środowisku\"\r\n                    frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>\r\n            <p>Film edukacyjny</p>\r\n        </div>\r\n    </section>', 1),
(3, 'gatunek', '\r\n\r\n	<h1 class=\"header\">Wybór gatunku</h1>\r\n	<h2>Wybór odpowiedniego gatunku żółwia wodnego to kluczowy krok w hodowli. Najpopularniejsze gatunki to żółw błotny i żółw czerwonolicy. Każdy z nich ma swoje unikalne wymagania dotyczące środowiska i diety. Zanim zdecydujesz się na zakup, warto dokładnie zapoznać się z informacjami na temat wybranego gatunku, aby upewnić się, że spełnia on Twoje oczekiwania. Pamiętaj, że niektóre gatunki mogą osiągać duże rozmiary, co wymaga większej przestrzeni do życia. </h2>\r\n	\r\n	<div class=\"galerry\">\r\n	 <td><img src=\"obrazy/blotny.jpg\" width=47% height=75% alt=\"zolw blotny\"></td>\r\n	  \r\n        \r\n	 <td><img src=\"obrazy/czerwony.jpg\" width=47% height=75% alt=\"zolw czerwonolicy\"></td>\r\n	 \r\n	</div>\r\n	\r\n', 1),
(4, 'glowna', ' <main>\r\n			\r\n        <h2 class=\"header\">Witaj w naszej galerii!</h2>\r\n        \r\n                \r\n                \r\n               \r\n            \r\n                <td><img src=\"obrazy/obraz1.jpg\" width=\"500\" height=\"400\" alt=\"Obraz 1\"></td>\r\n                <td><img src=\"obrazy/obraz2.jpg\" class=\"scaled-image\" alt=\"Obraz 2\"></td>\r\n                <td><img src=\"obrazy/obraz3.jpg\" class=\"scaled-image\" alt=\"Obraz 3\"></td>\r\n                <td><img src=\"obrazy/obraz4.jpg\" class=\"scaled-image\" alt=\"Obraz 4\"></td>\r\n                <td><img src=\"obrazy/obraz5.jpg\" class=\"scaled-image\" alt=\"Obraz 5\"></td>\r\n                <td><img src=\"obrazy/obraz6.jpg\" class=\"scaled-image\" alt=\"Obraz 6\"></td>\r\n                <td><img src=\"obrazy/obraz7.jpg\" width=\"550\" height=\"400\" alt=\"Obraz 7\"></td>\r\n                <td><img src=\"obrazy/obraz8.jpg\"  width=\"550\" height=\"400\" alt=\"Obraz 8\"></td>\r\n                <td><img src=\"obrazy/obraz9.jpg\" width=\"570\" height=\"400\" alt=\"Obraz 9\"></td>\r\n				\r\n			\r\n           \r\n        \r\n    </main>', 1),
(5, 'kontakt', '\r\n	  <main>\r\n        <h2>Skontaktuj się z nami</h2>\r\n        <form method=\"post\" enctype=\"text/plain\">\r\n            <label for=\"name\">Imię:</label><br>\r\n            <input type=\"text\" id=\"name\" name=\"name\"><br><br>\r\n            <label for=\"email\">E-mail:</label><br>\r\n            <input type=\"text\" id=\"email\" name=\"email\"><br><br>\r\n            <label for=\"message\">Wiadomość:</label><br>\r\n            <textarea id=\"message\" name=\"message\"></textarea><br><br>\r\n            <input type=\"submit\" value=\"Wyślij\">\r\n        </form>\r\n    </main>\r\n\r\n	   \r\n	\r\n', 1),
(6, 'temperatura', '\r\n	<h1 class=\"header\">Temperatura i oświetlenie</h1>\r\n	<h2>Utrzymanie odpowiedniej temperatury w akwarium jest kluczowe dla zdrowia żółwia. Woda powinna mieć temperaturę w zakresie 24-28°C. Dodatkowo, ważne jest stosowanie lamp UVB, które pozwalają żółwiowi wytwarzać witaminę D3, niezbędną do przyswajania wapnia. Bez odpowiedniego oświetlenia i ciepła, żółw może stać się osłabiony i podatny na choroby.	</h2>\r\n	\r\n	<td><img src=\"obrazy/lampa.jfif\" width=50% height=70% alt=\"lampa\"></td>\r\n', 1),
(7, 'zdrowie', '\r\n	\r\n	<h1 class=\"header\">Zdrowie i higiena</h1>\r\n	<h2>Zdrowie żółwia jest najważniejsze, dlatego regularne kontrole są niezbędne. Obserwuj swojego żółwia pod kątem objawów chorobowych, takich jak apatia, brak apetytu czy zmiany w wyglądzie. Regularnie zmieniaj wodę w akwarium i dbaj o jego czystość, aby zapobiec chorobom. W razie jakichkolwiek wątpliwości, zawsze skonsultuj się z weterynarzem specjalizującym się w gadach.	</h2>\r\n	\r\n	<td><img src=\"obrazy/koniec.jpg\" width=100% height=70% alt=\"zdr\"></td>\r\n	\r\n', 1),
(8, 'zywienie', '\r\n	<h1 class=\"header\">Żywienie</h1>\r\n	<h2>Żółwie wodne są wszystkożerne, co oznacza, że ich dieta powinna być zróżnicowana. Możesz podawać im granulki przeznaczone dla żółwi, świeże warzywa, a także białko w postaci ryb i owadów. Ważne jest, aby nie przesadzać z ilością jedzenia, ponieważ żółwie mają tendencję do nadwagi. Regularne monitorowanie diety pomoże utrzymać ich w dobrej kondycji.	</h2>\r\n	\r\n	<td><img src=\"obrazy/dieta.jpg\" width=100% height=70% alt=\"dieta\"></td>\r\n	\r\n', 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `produkty`
--

CREATE TABLE `produkty` (
  `ID` int(11) NOT NULL,
  `nazwa` varchar(255) NOT NULL,
  `opis` text NOT NULL,
  `cena` decimal(10,2) NOT NULL,
  `kategoria_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produkty`
--

INSERT INTO `produkty` (`ID`, `nazwa`, `opis`, `cena`, `kategoria_id`, `status`) VALUES
(1, 'chlep', 'dobry smaczny', 4.00, 2, 1),
(2, 'test2', 'test', 12.33, 3, 1),
(3, 'mleko', 'krowie', 3.99, 1, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `zarzadzanie`
--

CREATE TABLE `zarzadzanie` (
  `ID` int(100) NOT NULL,
  `matka` int(255) NOT NULL DEFAULT 0,
  `nazwa` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `zarzadzanie`
--

INSERT INTO `zarzadzanie` (`ID`, `matka`, `nazwa`) VALUES
(2, 1, 'chlep11'),
(3, 1, 'chlep11'),
(5, 1, 'chlep'),
(6, 0, 'chlep'),
(7, 1, 'nabiał'),
(8, 0, 'nabiał'),
(9, 0, 'pieczywo');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `page_list`
--
ALTER TABLE `page_list`
  ADD PRIMARY KEY (`ID`);

--
-- Indeksy dla tabeli `produkty`
--
ALTER TABLE `produkty`
  ADD PRIMARY KEY (`ID`);

--
-- Indeksy dla tabeli `zarzadzanie`
--
ALTER TABLE `zarzadzanie`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `page_list`
--
ALTER TABLE `page_list`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `produkty`
--
ALTER TABLE `produkty`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `zarzadzanie`
--
ALTER TABLE `zarzadzanie`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
