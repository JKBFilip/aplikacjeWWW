<?php
echo 'Zawartość pliku załączanego: <br />';
echo 'To jest przykładowy tekst, który został dodany z innego pliku php.<br />';
?>
