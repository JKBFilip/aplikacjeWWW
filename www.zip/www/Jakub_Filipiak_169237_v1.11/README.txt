przez pomyłkę zmieniłem nazwe wersji z v1.6 na v1.7 aczkolwiek chodzi tutaj o wersje v1.6 czyli z lab7
